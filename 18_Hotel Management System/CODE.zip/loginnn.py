from subprocess import call
from tkinter import *
import tkinter.ttk as ttk

class checkin:
    def __init__(self):
        root = Tk()
        root.geometry("1530x1000")
        root.title("HOTEL MANAGEMENT SYSTEM")
        root.configure(background="#000000")
        root.configure(highlightbackground="#000000")
        root.configure(highlightcolor="black")