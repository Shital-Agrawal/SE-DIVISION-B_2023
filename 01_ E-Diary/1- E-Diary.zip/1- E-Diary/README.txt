Title of project-E-Diary
Group Members- Kaushik Rajesh Prabhu Nerurkar (21104016),Amogh Parulekar (21104001), Riya Patel (21104141), Ajit Pawar (21104054)

E-Diary is a Web-based application.

E-Diary is a project that aims to provide a digital platform for users to manage their tasks.
 It is a comprehensive tool that allows users to track their progress, and manage their day-to-day activities.
The project focuses on providing an easy-to-use interface for the user to access their information. People often need information while on the go. 
Sometimes the information required is essential to the task at hand, people use a variety of strategies to find a way to do their tasks efficiently.
The E-Diary System helps them to set down their tasks at a place and add notes to it It helps them save time and effort by organizing their tasks and activities in one place. 
It also helps them track their progress and stay on top of their goals.
The system would be having a login system for user login. 
Users can log in and update/delete/create notes.