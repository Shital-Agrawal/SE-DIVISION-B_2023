

from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    dependencies = [
        ('bbApp', '0002_blood_group_status'),
    ]

    operations = [
        migrations.CreateModel(
            name='Donation',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('donor_name', models.CharField(max_length=500)),
                ('donor_contact', models.CharField(max_length=250)),
                ('donor_email', models.CharField(max_length=250)),
                ('donor_address', models.TextField(blank=True, null=True)),
                ('donor_gender', models.CharField(choices=[('Male', 'Male'), ('Female', 'Female')], max_length=30)),
                ('transfustion_date', models.DateField()),
                ('donation_volume', models.FloatField(default=0)),
                ('date_created', models.DateTimeField(default=django.utils.timezone.now)),
                ('date_updated', models.DateTimeField(auto_now=True)),
                ('blood_group', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='bbApp.blood_group')),
            ],
        ),
    ]
