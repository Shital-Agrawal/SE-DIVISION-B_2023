
from tkinter import *

from PIL import ImageTk


def click_main():
    from subprocess import call
    call(["python", "main.py"])


class Login:
    def __init__(self):
        root = Tk()
        root.geometry("1530x1000")
        root.title("HOTEL MANAGEMENT SYSTEM")
        root.configure(background="#000000")
        root.configure(highlightbackground="#000000")
        root.configure(highlightcolor="black")

        font14 = "-family {Segoe UI} -size 25 -weight bold -slant " \
                 "roman -underline 0 -overstrike 0"
        font16 = "-family {Swis721 BlkCn BT} -size 30 -weight bold " \
                 "-slant roman -underline 0 -overstrike 0"
        font9 = "-family {Segoe UI} -size 15 -weight normal -slant " \
                "roman -underline 0 -overstrike 0"

        self.Frame6 = Frame(root)
        self.Frame6.place(relx=0.02, rely=0.04, relheight=0.85, relwidth=0.95)
        self.Frame6.configure(borderwidth="2")
        self.Frame6.configure(relief=GROOVE)
        self.Frame6.configure(highlightcolor="black")
        self.Frame6.configure(background="#ffffff")
        self.Frame6.configure(width=657)

        img = ImageTk.PhotoImage(file='imgggg.png')
        label = Label(self.Frame6, image=img)
        label.place(x=0, y=0)

        self.Message6 = Message(self.Frame6)
        self.Message6.place(relx=0.10, rely=0.03, relheight=0.11, relwidth=0.81)
        self.Message6.configure(background="#D8D9DA")
        self.Message6.configure(foreground="#000000")
        self.Message6.configure(highlightbackground="#d9d9d9")
        self.Message6.configure(highlightcolor="black")
        self.Message6.configure(font=font16)
        self.Message6.configure(text='''WELCOME''')
        self.Message6.configure(width=700)

        self.Message6 = Message(self.Frame6)
        self.Message6.place(relx=0.43, rely=0.20, relheight=0.11, relwidth=0.51)
        self.Message6.configure(background="#ffffff")
        self.Message6.configure(foreground="#000000")
        self.Message6.configure(highlightbackground="#000000")
        self.Message6.configure(highlightcolor="black")
        self.Message6.configure(font=font14)
        self.Message6.configure(text='''Member Login''')
        self.Message6.configure(width=700)

        self.Message6 = Message(self.Frame6)
        self.Message6.place(relx=0.50, rely=0.35, relheight=0.11, relwidth=0.15)
        self.Message6.configure(background="#ffffff")
        self.Message6.configure(foreground="#000000")
        self.Message6.configure(highlightbackground="#000000")
        self.Message6.configure(highlightcolor="black")
        self.Message6.configure(font=font9)
        self.Message6.configure(text='''Enter your Username :''')
        self.Message6.configure(width=700)

        self.Message6 = Message(self.Frame6)
        self.Message6.place(relx=0.50, rely=0.45, relheight=0.11, relwidth=0.15)
        self.Message6.configure(background="#ffffff")
        self.Message6.configure(foreground="#000000")
        self.Message6.configure(highlightbackground="#000000")
        self.Message6.configure(highlightcolor="black")
        self.Message6.configure(font=font9)
        self.Message6.configure(text='''Enter Password :''')
        self.Message6.configure(width=700)

        self.Entry5 = Entry(self.Frame6)
        self.addr = StringVar()
        self.Entry5.place(relx=0.70, rely=0.39, height=25, relwidth=0.16)
        self.Entry5.configure(background="white")
        self.Entry5.configure(disabledforeground="#bfbfbf")
        self.Entry5.configure(foreground="#000000")
        self.Entry5.configure(highlightbackground="#ffffff")
        self.Entry5.configure(highlightcolor="black")
        self.Entry5.configure(insertbackground="black")
        self.Entry5.configure(selectbackground="#e6e6e6")
        self.Entry5.configure(selectforeground="black")

        self.Entry5 = Entry(self.Frame6)
        self.addr = StringVar()
        self.Entry5.place(relx=0.70, rely=0.48, height=25, relwidth=0.16)
        self.Entry5.configure(background="white")
        self.Entry5.configure(disabledforeground="#bfbfbf")
        self.Entry5.configure(foreground="#000000")
        self.Entry5.configure(highlightbackground="#ffffff")
        self.Entry5.configure(highlightcolor="black")
        self.Entry5.configure(insertbackground="black")
        self.Entry5.configure(selectbackground="#e6e6e6")
        self.Entry5.configure(selectforeground="black")

        self.Button3 = Button(self.Frame6)
        self.Button3.place(relx=0.62, rely=0.60, height=50, width=150)
        self.Button3.configure(activebackground="#d9d9d9")
        self.Button3.configure(activeforeground="#000000")
        self.Button3.configure(background="#D7A1F9")
        self.Button3.configure(disabledforeground="#bfbfbf")
        self.Button3.configure(font=font9)
        self.Button3.configure(foreground="#000000")
        self.Button3.configure(highlightbackground="#d9d9d9")
        self.Button3.configure(highlightcolor="black")
        self.Button3.configure(pady="0")
        self.Button3.configure(text='''Login''')
        self.Button3.configure(width=566)
        self.Button3.configure(command=click_main)

        root.mainloop()

if __name__ == '__main__':
    Welcome = Login()
