import random
def dice():
    move = random.randrange(1, 7, 1)
    return move
    
