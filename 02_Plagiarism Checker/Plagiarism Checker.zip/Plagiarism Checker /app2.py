from flask import Flask, render_template, send_file
import pymongo
import os
import re
from pdfkit import from_file

app = Flask(__name__)

# Connect to the MongoDB database
client = pymongo.MongoClient('mongodb+srv://dhruvtrivedi2439:dhruvtrivedi@plagiarismdataset.tj5s1wr.mongodb.net/test')
db = client['python']
collection = db['assignments']

# Define the paths of the input and output files
input_file_path = './output/check.txt'
output_file_path = './report/report.pdf'

@app.route('/')
def home():
    return render_template('report.html')

@app.route('/generate-report')
def generate_report():
    # Open and read the input file
    with open(input_file_path, 'r') as input_file:
        input_text = input_file.read()

    # Clean the input text by removing all non-alphanumeric characters and converting it to lowercase
    clean_input_text = re.sub(r'\W+', ' ', input_text).lower()

    # Retrieve all the documents from the MongoDB collection
    documents = collection.find()

    # Iterate through each document and compare it with the input text
    plagiarism_count = 0
    plagiarism_records = []
    for document in documents:
        clean_document_text = re.sub(r'\W+', ' ', document['assignment']).lower()
        if clean_document_text == clean_input_text:
            plagiarism_count += 1
            plagiarism_records.append({
                'document_id': document['_id'],
                'plagiarized_text': document['assignment'],
                'matching_text': clean_document_text
            })

    # Calculate the percentage of plagiarism
    plagiarism_percentage = round(plagiarism_count / collection.count_documents({}) * 100, 2)

    # Generate the plagiarism report
    report = '<html><head><style>'
    report += 'table {border-collapse: collapse; width: 100%;}'
    report += 'th, td {border: 1px solid black; padding: 8px; text-align: left;}'
    report += 'th {background-color: #4CAF50; color: white;}'
    report += '.percentage {font-size: 24px; font-weight: bold;}'
    report += '</style></head><body>'
    report += f'<h1>Plagiarism Report</h1>'
    report += f'<p class="percentage">Plagiarism Percentage: {plagiarism_percentage}%</p>'
    if plagiarism_records:
        report += '<table>'
        report += '<tr><th>Document ID</th><th>Plagiarized Text</th><th>Matching Text</th></tr>'
    for record in plagiarism_records:
        report += f'<tr><td>{record["document_id"]}</td><td>{record["plagiarized_text"]}</td><td>{record["matching_text"]}</td></tr>'
    report += '</table>'    
    report += '</body></html>'

    # Write the plagiarism report to a text file
    with open('./report/report.html', 'w') as report_file:
        report_file.write(report)

    # Convert the plagiarism report to a PDF file with the new CSS file
    from_file('./report/report.html', output_file_path, css='./static/styles.css')

    # Insert the input data into the MongoDB collection
    collection.insert_one({'assignment': input_text})

    return send_file(output_file_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, port=5001)
