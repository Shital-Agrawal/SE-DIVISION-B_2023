from flask import Flask, render_template, request
import language_tool_python

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('spell.html')

@app.route('/check_text', methods=['POST'])
def check_text():
    text = request.form['text']
    tool = language_tool_python.LanguageTool('en-US')
    matches = tool.check(text)
    return render_template('spell.html', results=matches)

if __name__ == '__main__':
    app.run(debug=True, port=5002)
