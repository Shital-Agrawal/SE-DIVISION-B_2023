import subprocess
from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk



def tictactoe():
    subprocess.call(["python", "TKtictac-master\__main__.py"])

def connect():
    subprocess.call(["python", "connect.py"])

def tinyracer():
    subprocess.call(["python", "racing.py"])

def pacworld():
    subprocess.call(["python", "Python-PacWorld-master\pacworld.py"])

def snake():
    subprocess.call(["python", "Snake-and-Ladder-master\Snake and Ladder\main.py"])

class Language_Solutions:
    def __init__(self,root):
        
        image = Image.open('background.png')
        photo = ImageTk.PhotoImage(image)
        self.root=root
        self.root.geometry("1190x680+80+10")
        self.root.title("𝕋𝕚𝕔 𝕋𝕒𝕔 𝕋𝕠𝕖")
        self.root.wm_iconphoto(True, photo)

        title_lb1=Label(text="𝕋𝕚𝕔 𝕋𝕒𝕔 𝕋𝕠𝕖",font=(30),bg="snow",fg="blue")
        title_lb1.place(x=400,y=10)

        #Load background image
        image = Image.open("background.png")
        self.background_image = ImageTk.PhotoImage(image)
        background_label = Label(self.root, image=self.background_image)
        background_label.place(x=0, y=0, relwidth=1, relheight=1)

        title_lb1 = Label(text="𝙏𝙞𝙘 𝙏𝙖𝙘 𝙏𝙤𝙚", font=("Arial", 30), fg="blue")
        title_lb1.place(x=500,y=30)

        #snakeladder
        img = Image.open(r"sl.jpg")
        img = img.resize((250, 250), resample=Image.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        b1 = Button(image=self.photoimg, cursor="hand2", command=snake)
        b1.place(x=10, y=10, width=250,height=250)

        b1_1 = Button(text="𝓢𝓷𝓪𝓴𝓮 𝓐𝓷𝓭 𝓛𝓪𝓭𝓭𝓮𝓻𝓼", cursor="hand2", font=( 13), bg="white", fg="brown", command=snake)
        b1_1.place(x=10, y=260, width=250, height=40)

        # connect4
        img1 = Image.open(r"connect4.jpg")
        img1 = img1.resize((250, 250), resample=Image.LANCZOS)
        self.photoimg1 = ImageTk.PhotoImage(img1)

        b2 = Button(image=self.photoimg1, cursor="hand2", command=connect)
        b2.place(x=930, y=10, width=250, height=250)

        b2_1 = Button(text="𝓒𝓸𝓷𝓷𝓮𝓬𝓽 4", cursor="hand2", font=( 13), bg="white", fg="brown", command=connect )
        b2_1.place(x=930, y=260, width=250, height=40)

        # tinyracer
        img2 = Image.open(r"car.jpg")
        img2 = img2.resize((250, 250), resample=Image.LANCZOS)
        self.photoimg2 = ImageTk.PhotoImage(img2)

        b3 = Button(image=self.photoimg2, cursor="hand2", command=tinyracer)
        b3.place(x=10, y=380, width=250, height=250)

        b3_1 = Button(text="𝓣𝓲𝓷𝔂 𝓡𝓪𝓬𝓮𝓻", cursor="hand2", font=( 13), bg="white", fg="brown", command=tinyracer)
        b3_1.place(x=10, y=630, width=250, height=40)

        # pacworld
        img3 = Image.open(r"pacworld.jpg")
        img3 = img3.resize((250, 250), resample=Image.LANCZOS)
        self.photoimg3 = ImageTk.PhotoImage(img3)

        b4 = Button(image=self.photoimg3, cursor="hand2", command=pacworld)
        b4.place(x=930, y=380, width=250, height=250)

        b4_1 = Button(text="𝓟𝓪𝓬 𝓦𝓸𝓻𝓵𝓭", cursor="hand2", font=( 13), bg="white", fg="brown", command=pacworld)
        b4_1.place(x=930, y=630, width=250, height=40)

        # tictactoe
        img4 = Image.open(r"tictactoe.png")
        img4 = img4.resize((250, 250), resample=Image.LANCZOS)
        self.photoimg4 = ImageTk.PhotoImage(img4)

        b5 = Button(image=self.photoimg4, cursor="hand2", command=tictactoe)
        b5.place(x=475, y=250, width=250, height=250)

        b5_1 = Button(text="𝓣𝓲𝓬 𝓣𝓪𝓬 𝓣𝓸𝓮", cursor="hand2", font=( 13), bg="white", fg="brown", command=tictactoe)
        b5_1.place(x=475, y=500, width=250, height=40)

        
if __name__ == "__main__":
    root = Tk()
    obj = Language_Solutions(root)
    root.mainloop()
